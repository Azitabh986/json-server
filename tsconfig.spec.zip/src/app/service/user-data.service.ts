import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {
  hostUrl:any='http://localhost:3000';
  constructor(private httpClient:HttpClient) { }

  getUserDetails<UserDetailsArr>() {
    return this.httpClient.get<UserDetailsArr>(this.hostUrl+"/users");
  }
  addPerson(person:UserDetails): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    // const body=JSON.stringify(person);
    console.log("before adding: ",person)
    return this.httpClient.post(this.hostUrl + '/users', person,{'headers':headers}).pipe(
      map(this.extractData),
      catchError(this.handleErrorObservable))
  }
  private extractData(res: any) {
    let body = res;
    return body;
  }
  private handleErrorObservable(error: any) {
    console.error(error.message || error);
    return throwError(error);
  }
}

export class UserDetails{
  id:number;
  userName:string;
  password:string;
  constructor(id:number,userName:string,password:string){
    this.id=id;
    this.userName=userName;
    this.password=password;
  }
}
export class UserDetailsArr{
  UserDetailsArr=new Array<UserDetails>();
}