import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UpdateService {
  constructor() { }
  private loggedIn = new Subject<boolean>();
  public getLoggedIn() {
    return this.loggedIn;
  }
  public setLoggedIn(value:any) {
    this.loggedIn.next(value)
  }
 
}
