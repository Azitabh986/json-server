import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../service/auth.service';
import { UpdateService } from '../service/update.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  className:string='login';
  checkLoggedIn:boolean=false;
  constructor(private route:Router,private updateService:UpdateService,private authService:AuthService) { }

  ngOnInit(): void {
    console.log("Header Onit")
    this.updateService.getLoggedIn().subscribe(res=>{
      this.checkLoggedIn=res;
      console.log("Header Log",this.checkLoggedIn)
    })
  }
  navigate(value:any){
    this.className=value;
    this.route.navigate([value]);
  }
  triggerLogout(){
    this.authService.logout();
    this.updateService.setLoggedIn(false);
    this.route.navigate(['/login'])
  }
}
