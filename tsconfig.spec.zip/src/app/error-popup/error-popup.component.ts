import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-popup',
  templateUrl: './error-popup.component.html',
  styleUrls: ['./error-popup.component.scss']
})
export class ErrorPopupComponent implements OnInit {
  close:boolean=true;
  constructor() { }

  ngOnInit(): void {
    this.close=true;
  }
  hidePopup(){
    this.close=!this.close;
  }
}
