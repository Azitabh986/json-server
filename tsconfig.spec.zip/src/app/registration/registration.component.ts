import { Component, DoCheck, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserDataService, UserDetails } from '../service/user-data.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit,DoCheck{
  checkUserName:boolean=false;
  registered:boolean=false;
  profileForm = new FormGroup({
    userName: new FormControl('',[Validators.required,Validators.minLength(5)]),
    password: new FormControl('',[Validators.required,Validators.minLength(8)]),
    confirmPassword: new FormControl('',[Validators.required,Validators.minLength(8)])
  });
  users:any[]=[];
  
 
  constructor(private userService:UserDataService,private httpRouter:Router) { }
  ngDoCheck(){
    // console.log(this.profileForm.value)
  }

  ngOnInit(): void {
    this.userService.getUserDetails().subscribe(userNameList => {
      for(const data of (userNameList as any)){
        this.users.push({
          id:data.id,
          userName:data.userName,
          password:data.password
        })
      }
    })
  }
  onSubmit(){
    // console.log(this.profileForm.value)
    if(this.profileForm.value.confirmPassword !== this.profileForm.value.password && !this.checkUserName){
      window.alert("Password and Confirm Password doesn't match!! Please re-enter and try again!!");
    } else{
      const id=this.users[this.users.length-1].id+1;
      console.log("ID:",id)
      if(!this.checkUserName){
        const user=new UserDetails(id,this.profileForm.value.userName,this.profileForm.value.password)
        const pf=this.userService.addPerson(user
        ).subscribe(res=>{
          if(res){
          this.registered=true;
        }else{
          window.alert("Something went wrong");
        }
        });
        
      }
      
    }
  }
  checkUserNameFun(event:any){
    this.checkUserName=false;
    const user=this.users.filter((d=> d.userName == event.target.value))
    if(user.length>0){
      this.checkUserName=true;
    }
  }
  resetFun(){
    this.profileForm.reset();
    this.registered=false;
  }
}
