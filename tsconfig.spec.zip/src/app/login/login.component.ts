import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, UserCred } from '../service/auth.service';
import { UpdateService } from '../service/update.service';
import { UserDataService } from '../service/user-data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm = new FormGroup({
    userName: new FormControl('',Validators.minLength(4)),
    password: new FormControl('',Validators.minLength(8)),
  });
  users:any[]=[];
  logoutButton:boolean=false;
  constructor(private loginService:UserDataService,private router:Router,
    private authService:AuthService,private updateService:UpdateService) { }
  
  ngOnInit(): void {
    this.checkLoginAuth();
  }
  checkLoginAuth(){
    this.loginService.getUserDetails()
      .subscribe(res=>{
       for(const user of res as any){
        this.users.push({
          userName:user.userName,
          password:user.password
        })
       }
      })
      
  }
  onSubmit(){
    console.log(this.loginForm.value)
    const data=this.users.filter(user=> user.userName == this.loginForm.value.userName && user.password == this.loginForm.value.password)
    console.log(data)
    if(data.length>0){
      this.updateService.setLoggedIn(true);
      // window.location.reload();
      this.router.navigate(['/home'])
      this.authService.signIn(new User(data[0]?.userName,data[0]?.password));
      this.logoutButton=true;
    }else{
      window.alert("LOGIN FAILED!!!! Please login AGAIN!!")
    }
  }
}
export class User implements UserCred{
  userName: string;
  password: string;
  constructor(userName:string,password:string){
    this.userName=userName;
    this.password=password;
  }

}