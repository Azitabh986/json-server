import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PetDetails, UserDataService } from '../service/user-data.service';

@Component({
  selector: 'app-add-pet',
  templateUrl: './add-pet.component.html',
  styleUrls: ['./add-pet.component.scss']
})
export class AddPetComponent implements OnInit {
  pets:any[]=[];
  resultSaved:boolean=false;
  petProfile=new FormGroup({
    petName:new FormControl('',[Validators.required,Validators.minLength(5)]),
    petPlace:new FormControl('',[Validators.required,Validators.minLength(2)]),
    petAge:new FormControl('',[Validators.required,Validators.minLength(2)])
  })
  constructor(private petService:UserDataService,private route:Router) { }

  ngOnInit(): void {
    this.petService.getPetDetails()
      .subscribe(pet=>{
        for(const p of pet as any){
          this.pets.push({
            id:p.id
          })
        }
      })
  }
  savePet(){
    
    this.petService.addPets(new PetDetails(this.pets[this.pets.length-1].id+1,
      this.petProfile.value.petName,this.petProfile.value.petPlace,this.petProfile.value.petAge,Number(sessionStorage.getItem("id"))))
      .subscribe(returnPet=>{
        if(returnPet){
          this.resultSaved=true;
        }else{
          window.alert("Something went wrong!!!")
        }
      })
  }
  cancelPet(){
    this.petProfile.reset();
  }
}
