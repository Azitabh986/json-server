import { Component, OnInit } from '@angular/core';
import { UserDataService } from '../service/user-data.service';

@Component({
  selector: 'app-my-pet',
  templateUrl: './my-pet.component.html',
  styleUrls: ['./my-pet.component.scss']
})
export class MyPetComponent implements OnInit {
  pets:any[]=[];
  petHeaders:any[]=["#","Pet Name","Place", "Age"]
  petVars:any[]=["id","petName","petPlace","petAge"]
  constructor(private myPetDetails:UserDataService) { }

  ngOnInit(): void {
    this.myPetDetails.getPetDetails()
      .subscribe(pet=>{
        let temp=1;
         for(const i of pet as any){
          if(i.petOwnerId == Number(sessionStorage.getItem("id"))){
            this.pets.push({
              id:temp++,
              petName:i.petName,
              petAge:i.petAge,
              petPlace:i.petPlace
            })
          }
         }
      })
  }

}
