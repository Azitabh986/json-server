import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserDataService } from '../service/user-data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  pets:any[]=[];
  petsSearched:any[]=[];
  petHeaders:any[]=["#","Pet Name","Place", "Age"];
  petHeadersCopy:any[]=["#","Pet Name","Place", "Age","Action"]
  petVars:any[]=["id","petName","petPlace","petAge"];
  petVarsCopy:any[]=["id","petName","petPlace","petAge","BuyOption"];
  openPopupCheck:boolean=false;
  buyOptionOpen:boolean=false;
  petNameBuy:any;
  searchProfile=new FormGroup({
    petName:new FormControl('',Validators.required),
    petPlace:new FormControl('',Validators.required),
    petAge:new FormControl('',Validators.required)
  })

  constructor(private userDetails:UserDataService) { }

  ngOnInit(): void {
    this.pets=[]
    console.log("Home NGONIT",this.pets)
    this.userDetails.getPetDetails().subscribe(res=>{
      for(const r of  res as any){
        this.pets.push({
          id:r.id,
          petName:r.petName,
          petPlace:r.petPlace,
          petAge:r.petAge,
          petOwnerId:r.petOwnerId,
          BuyOption:r.petOwnerId == 0 ? BuyOption[0]:BuyOption[1]
        })
      }
    })
    console.log("Pets Array:",this.pets)
  }
  openPopup(){
    this.openPopupCheck=!this.openPopupCheck;
    this.petsSearched=[];
    this.searchProfile.reset();
  }
  searchRes(){
    this.petsSearched=[];
    this.pets.filter(r=>{
      if(r.petName.toLocaleLowerCase()==this.searchProfile.value.petName.toLocaleLowerCase()
        && r.petPlace.toLocaleLowerCase()==this.searchProfile.value.petPlace.toLocaleLowerCase()
        && r.petAge.toLocaleLowerCase()==this.searchProfile.value.petAge.toLocaleLowerCase()
      ){
        this.petsSearched.push({
          id:r.id,
          petName:r.petName,
          petPlace:r.petPlace,
          petAge:r.petAge,
        })
      }
    })
    
  }
  assignUserName(value:object){
    this.petNameBuy=value;
    console.log(this.petNameBuy)
    this.closePop();
  }
  closePop(){ 
    this.buyOptionOpen=!this.buyOptionOpen;
  }
  updatePetOwner(){
    delete this.petNameBuy.BuyOption;
    const id=Number(sessionStorage.getItem("id"))
    this.petNameBuy.petOwnerId=id;
    console.log("Aftr Delete: ",this.petNameBuy)
    this.userDetails.updatePets(this.petNameBuy,this.petNameBuy.id)
      .subscribe(res=>{
        if(res){
          window.alert("Transaction Successful!!!! To close this Click Okay!!");
          this.closePop();
        }else{
          window.alert("Something went wrong!!! ");
        }
      })
      this.petNameBuy.BuyOption='Sold';
  }
}
export enum BuyOption{
  Buy,
  Sold
}