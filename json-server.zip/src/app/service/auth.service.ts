import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor() { }
  
  public signIn(user: UserCred){
    sessionStorage.setItem("userName",user.userName);
  }
  public logIn(){
    return sessionStorage.getItem("userName")!== null;
  }
  public logout(){
    sessionStorage.removeItem("userName");
    sessionStorage.removeItem("id");
  }
}
export interface UserCred{
  userName:string;
  password:string;
}
